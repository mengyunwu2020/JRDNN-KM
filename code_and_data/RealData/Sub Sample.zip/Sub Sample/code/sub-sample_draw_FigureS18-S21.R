##############################################################
####################   Figure S18   ##########################
##############################################################
library(here)
library(tidyverse)
library(readxl)
library(patchwork)


base_path_s18 <- here(
  "RealData", 
  "Sub Sample", 
  "result_data", 
  "Cluster"
)


# Define color palette (maintain original color scheme)
custom_colors <- c(
  "JRDNN-KM" = "#377EB8",   # Blue
  "SC3" = "red",            # Red
  "BLGGM" = "#4DAF4A",      # Green
  "Seurat" = "orange"       # Orange
)

# Define method list and dataset list (modify order and capitalization)
methods <- c("BLGGM", "JRDNN", "SC3", "Seurat")
datasets_original <- c("luad", "pbmc", "mescs", "liver", "uterus")
datasets_display <- c("LUAD", "PBMC", "mESCs", "Mouse Liver", "Mouse Uterus")

# Data loading and processing function 
load_and_process_data <- function(base_path, datasets_original, methods) {
  all_data <- list()
  
  # Iterate through each dataset folder (using original names)
  for (dataset in datasets_original) {
    # 核心修改：用here替代file.path
    dataset_path <- here(base_path, dataset)
    
    # Iterate through each method file
    data_list <- lapply(methods, function(method) {
      # Find Excel files for the method (handle different naming formats)
      file_pattern <- paste0("*", method, "*\\.xlsx")
      # 核心修改：list.files用here路径
      files <- list.files(path = dataset_path, pattern = file_pattern, full.names = TRUE)
      
      if (length(files) == 0) {
        warning(paste("No files found for", method, "in", dataset))
        return(NULL)
      }
      
      # Read data
      data <- read_excel(files[1])
      
      # Standardize column names (handle case/spaces)
      colnames(data) <- tolower(colnames(data))
      colnames(data) <- gsub(" ", "", colnames(data))
      
      # Check and extract ARI and NMI columns
      if (!all(c("ari", "nmi") %in% colnames(data))) {
        warning(paste(dataset, "-", method, "missing ARI/NMI columns"))
        return(NULL)
      }
      
      # Organize data
      data %>% 
        select(ari, nmi) %>% 
        mutate(
          Method = method,
          Dataset = dataset  # Store original name temporarily
        )
    }) %>% bind_rows()
    
    all_data[[dataset]] <- data_list
  }
  
  # Combine all data and convert to long format
  combined_data <- bind_rows(all_data) %>%
    pivot_longer(
      cols = c(ari, nmi), 
      names_to = "Metric", 
      values_to = "Value"
    ) %>%
    # Unify method naming (JRDNN -> JRDNN-KM)
    mutate(
      Method = case_when(
        Method == "JRDNN" ~ "JRDNN-KM",
        TRUE ~ Method
      ),
      # Replace dataset names with display names and set factor levels
      Dataset = factor(
        recode(Dataset, 
               "luad" = "LUAD", 
               "pbmc" = "PBMC", 
               "mescs" = "mESCs", 
               "liver" = "Mouse Liver", 
               "uterus" = "Mouse Uterus"),
        levels = datasets_display  # Control display order
      ),
      Method = factor(Method, levels = c("JRDNN-KM", "BLGGM", "SC3", "Seurat"))
    )
  
  return(combined_data)
}

# Load and process data
processed_data <- load_and_process_data(base_path_s18, datasets_original, methods)

# Filter valid data
if (!is.null(processed_data)) {
  # Extract ARI and NMI data separately
  filtered_data_ARI <- processed_data %>%
    filter(Metric == "ari")
  
  filtered_data_NMI <- processed_data %>%
    filter(Metric == "nmi")
} else {
  stop("Data loading failed, please check file paths and formats")
}

# Calculate center positions for each dataset (key: exact middle of each x-axis category)
dataset_centers <- seq_along(datasets_display)  # 1,2,3,4,5 correspond to dataset centers in new order

# Plotting function (add vertical light center lines for each dataset)
plot_metric <- function(data, y_label, y_breaks = NULL, y_limits = NULL, show_legend = FALSE) {
  # Auto calculate y-axis range (if not specified)
  if (is.null(y_limits)) {
    y_min <- floor(min(data$Value, na.rm = TRUE) * 10) / 10
    y_max <- ceiling(max(data$Value, na.rm = TRUE) * 10) / 10
    y_limits <- c(y_min, y_max)
  }
  
  # Auto generate y-axis ticks (if not specified)
  if (is.null(y_breaks)) {
    y_breaks <- seq(y_limits[1], y_limits[2], length.out = 6)
  }
  
  p <- ggplot(data, aes(x = Dataset, y = Value, fill = Method, color = Method)) +
    # Box plot (maintain original style)
    geom_boxplot(
      position = position_dodge(width = 0.8), 
      width = 0.7, 
      outlier.size = 0.5,  # Restore original outlier size
      alpha = 0.8
    ) +
    # Core: Add vertical light center lines for each dataset (consistent with original ARI plot style)
    geom_vline(
      xintercept = dataset_centers,    # Exact center position of each dataset
      color = "gray80",                # Very light gray, non-intrusive
      linewidth = 0.3,                 # Ultra-thin line width, minimalist style
      linetype = "solid",              # Solid line (consistent with original plot)
      alpha = 0.6                      # Low transparency, non-distracting
    ) +
    labs(x = "Datasets", y = y_label) +  # Change x-axis to Datasets
    theme_minimal() +
    theme(
      # Restore original theme style from code
      axis.text.x = element_text(size = 12, angle = 45, hjust = 1),  
      axis.text.y = element_text(size = 12),                        
      legend.title = element_blank(),
      legend.position = ifelse(show_legend, "left", "none"),
      axis.title = element_text(size = 14),
      legend.text = element_text(size = 10),
      # Grid line optimization (maintain original minimalist style)
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin = margin(10, 10, 10, 10)
    ) +
    # Apply custom colors
    scale_fill_manual(values = custom_colors) +
    scale_color_manual(values = custom_colors) +
    # Y-axis settings (default 0.5-1, consistent with original ARI plot)
    scale_y_continuous(
      breaks = y_breaks, 
      limits = y_limits,
      expand = c(0, 0)
    )
  
  return(p)
}

# Plot ARI (exact replication of original ARI plot parameters)
plot_ARI <- plot_metric(
  filtered_data_ARI, 
  y_label = "ARI Value", 
  y_breaks = seq(0.4, 1, 0.1),  
  y_limits = c(0.4, 1),         
  show_legend = TRUE
)

# Plot NMI (consistent style with ARI plot)
plot_NMI <- plot_metric(
  filtered_data_NMI, 
  y_label = "NMI Value", 
  y_breaks = seq(0.6, 1, 0.1),  
  y_limits = c(0.6, 1),         
  show_legend = FALSE
)

combined_plot <- (plot_ARI | plot_NMI) +
  plot_annotation(tag_levels = 'A') +
  plot_layout(
    guides = "collect", 
    widths = c(1, 1)  
  ) &
  theme(legend.position = 'left')  

# Display plot
print(combined_plot)

##############################################################
####################   Figure S19-S21   ######################
##############################################################
library(tidyverse)
library(readxl)
library(patchwork)


base_path_s19_s21 <- here(
  "RealData", 
  "Sub Sample", 
  "result_data", 
  "Network estimation"
)



# Define colors (strictly use specified color scheme)
custom_colors <- c(
  "JRDNN-KM" = "#377EB8",   # Blue
  "SC3" = "red",            # Red (backup)
  "Seurat" = "orange",      # Orange (backup)
  "BLGGM" = "#4DAF4A",      # Green
  "GENIE3" = "#FFCC00",     # Purple/Yellow
  "JGNsc" = "#80B7FF",      # Light Blue
  "JSEM" = "#778899",       # Grey
  "locCSN" = "#8FE506",     # Light Green
  "SpQN" = "#F781BF",       # Pink
  "Normalisr" = "#984EA3",  # Violet
  "CS-CORE" = "#A65628"     # Brown
)

# Define core parameters
methods <- c("JRDNN", "BLGGM", "GENIE3", "JGNsc", "JSEM", "locCSN", "SpQN", "Normalisr", "CS-CORE")
gold_standards_original <- c("CORUM", "PPI(F)", "PPI(P)", "PerturbAtlas")
gold_standards_display <- c("CORUM", "PPI(F)", "PPI(P)", "PerturbAtlas", "Mean") # Include mean term
datasets_original <- c("luad", "pbmc", "mescs", "liver", "uterus")
datasets_display <- c("LUAD", "PBMC", "mESCs", "Mouse Liver", "Mouse Uterus")
metrics <- c("Recall", "Precision", "F1")

# Revised data loading function (preserve iteration dimension, calculate gold standard mean per iteration)
load_and_process_data <- function(base_path, datasets_original, gold_standards_original, methods) {
  all_data <- list()
  
  # Iterate through each dataset
  for (dataset in datasets_original) {

    dataset_path <- here(base_path, dataset)
    
    # Iterate through each gold standard
    for (gs in gold_standards_original) {

      gs_path <- here(dataset_path, gs)
      
      if (!dir.exists(gs_path)) {
        warning(paste("Gold standard folder does not exist:", gs_path))
        next
      }
      
      # Iterate through each method
      method_data <- lapply(methods, function(method) {
        file_pattern <- paste0("*", method, "*\\.xlsx")
        files <- list.files(path = gs_path, pattern = file_pattern, full.names = TRUE)
        
        if (length(files) == 0) {
          warning(paste("Not found:", dataset, "-", gs, "-", method, "file"))
          return(NULL)
        }
        
        # Read data (preserve all rows, i.e., all iterations)
        data <- read_excel(files[1])
        
        # Standardize column names
        colnames(data) <- str_to_title(gsub(" ", "", colnames(data)))
        
        # Check required columns
        required_cols <- c("Recall", "Precision", "F1")
        if (!all(required_cols %in% colnames(data))) {
          warning(paste(dataset, "-", gs, "-", method, "missing required columns"))
          return(NULL)
        }
        
        # Add identifier columns for each row (iteration) + preserve original row number (iteration ID)
        data %>% 
          select(all_of(required_cols)) %>% 
          mutate(
            Iteration = row_number(),  # Key: add iteration ID for grouped mean calculation per iteration
            Method = method,
            GoldStandard = gs,
            Dataset = dataset
          )
      }) %>% bind_rows()
      
      all_data[[paste(dataset, gs, sep = "_")]] <- method_data
    }
  }
  
  # Combine all data and convert to long format (preserve Iteration column)
  combined_data <- bind_rows(all_data) %>%
    pivot_longer(
      cols = all_of(metrics),
      names_to = "Metric",
      values_to = "Value"
    ) %>%
    # Unify naming and factor levels
    mutate(
      Method = case_when(
        Method == "JRDNN" ~ "JRDNN-KM",
        TRUE ~ Method
      ),
      Dataset = factor(
        recode(Dataset, 
               "luad" = "LUAD", 
               "pbmc" = "PBMC", 
               "mescs" = "mESCs", 
               "liver" = "Mouse Liver", 
               "uterus" = "Mouse Uterus"),
        levels = datasets_display
      ),
      GoldStandard = factor(GoldStandard, levels = gold_standards_original),
      Method = factor(Method, levels = c("JRDNN-KM", "BLGGM", "JGNsc", "JSEM", 
                                         "SpQN", "Normalisr", "GENIE3", "locCSN", "CS-CORE"))
    )
  
  # Fix: calculate mean of 4 gold standards by "Iteration+Dataset+Method+Metric" (preserve iteration dimension)
  mean_data <- combined_data %>%
    group_by(Iteration, Dataset, Method, Metric) %>%  # Core: preserve Iteration, group by single iteration
    summarise(
      Value = mean(Value, na.rm = TRUE),  # Mean of 4 gold standards in single iteration
      GoldStandard = "Mean",              # Mark as mean term
      .groups = "drop"
    ) %>%
    mutate(
      GoldStandard = factor(GoldStandard, levels = gold_standards_display),
      # Ensure factor levels match original data
      Dataset = factor(Dataset, levels = datasets_display),
      Method = factor(Method, levels = c("JRDNN-KM", "BLGGM", "JGNsc", "JSEM", 
                                         "SpQN", "Normalisr", "GENIE3", "locCSN", "CS-CORE"))
    )
  
  # Combine original data and mean data (both preserve Iteration column)
  final_data <- bind_rows(
    combined_data %>% mutate(GoldStandard = factor(GoldStandard, levels = gold_standards_display)),
    mean_data
  ) %>%
    mutate(GoldStandard = factor(GoldStandard, levels = gold_standards_display))
  
  return(final_data)
}

# Load and process data (revised)
processed_data <- load_and_process_data(base_path_s19_s21, datasets_original, gold_standards_original, methods)

# Check data loading results
if (is.null(processed_data) || nrow(processed_data) == 0) {
  stop("Data loading failed, please check file paths and formats")
}

# Verify mean data: check if Mean term has multiple iteration values (box plot ready)
cat("===== Mean Term Data Verification =====\n")
print(processed_data %>% 
        filter(GoldStandard == "Mean", Metric == "Recall", Dataset == "LUAD", Method == "JRDNN-KM") %>% 
        select(Iteration, Value) %>% head(10))

# Calculate center positions for each dataset
dataset_centers <- seq_along(datasets_display)

# Define plotting function (2-row layout, box plot for mean term)
plot_single_metric <- function(data, metric_name, save_path) {
  plot_data <- data %>% filter(Metric == metric_name)
  
  # Set y-axis range
  y_limits <- c(0, 1)
  y_breaks <- seq(0, 1, 0.1)
  
  p <- ggplot(plot_data, aes(x = Dataset, y = Value, fill = Method, color = Method)) +
    # 2-row layout: 3 in first row, 2 in second (mean term in second row second position)
    facet_wrap(~GoldStandard, ncol = 3, scales = "free_x",  strip.position = "top") +
    # Box plot (mean term will show distribution due to preserved Iteration)
    geom_boxplot(
      position = position_dodge(width = 0.8),
      width = 0.7,
      outlier.size = 0.5,
      alpha = 0.8
    ) +
    # Dataset center vertical lines
    geom_vline(
      xintercept = dataset_centers,
      color = "gray80",
      linewidth = 0.3,
      alpha = 0.6
    ) +
    labs(
      x = "Datasets",
      y = paste(metric_name, "Score")
    ) +
    theme_minimal() +
    theme(
      # Force x-axis display for all facets (fix issue of only last row showing)
      strip.placement = "outside",
      axis.text.x = element_text(size = 10, angle = 45, hjust = 1),
      axis.text.y = element_text(size = 10),
      axis.title = element_text(size = 10, face = "bold"),
      strip.text = element_text(size = 10, face = "bold"),
      # Legend settings
      legend.title = element_blank(),
      legend.position = "bottom",
      legend.text = element_text(size = 10),
      legend.box = "horizontal",
      # Grid line optimization
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      # Spacing adjustment
      plot.margin = margin(5, 5, 5, 5),
      panel.spacing = unit(0.8, "cm"), # Increase facet spacing to avoid crowding
      legend.margin = margin(0, 0, 5, 0)
    ) +
    # Apply custom colors
    scale_fill_manual(values = custom_colors) +
    scale_color_manual(values = custom_colors) +
    # Y-axis settings
    scale_y_continuous(
      breaks = y_breaks,
      limits = y_limits,
      expand = c(0, 0)
    ) +
    # Force display of all datasets on x-axis (avoid missing)
    scale_x_discrete(drop = FALSE, limits = datasets_display)
  
  # Display plot
  print(p)
  
  return(p)
}

# Plot and save metric plots
# 1. Recall plot
plot_Recall <- plot_single_metric(
  processed_data, 
  metric_name = "Recall"
)

# 2. Precision plot
plot_Precision <- plot_single_metric(
  processed_data, 
  metric_name = "Precision"
)

# 3. F1 plot (optional)
plot_F1 <- plot_single_metric(
  processed_data, 
  metric_name = "F1"
)
